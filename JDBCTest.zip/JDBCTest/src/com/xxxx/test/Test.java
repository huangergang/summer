package com.xxxx.test;

import com.xxxx.dao.impl.BaseDaoImpl;
import com.xxxx.entity.Teacher;

import java.util.ArrayList;
import java.util.List;
/**
 *
 *
 * 测试类，测试增删改查操作测试
 */
public class Test {

    private static BaseDaoImpl base = new BaseDaoImpl();

    public static void main(String[] args) throws Exception {

//        List<Teacher> list = base.queryALL();
//        list.stream().forEach(System.out::println);

//        Teacher teacher = base.queryOfId(2);
//        System.out.println("teacher = " + teacher);

//        int row = base.insert(new Teacher("黄巢", "18888888999", "河南洛阳"));
//        System.out.println("受影响行数： " + row);

//
//        int rows = base.inserts(new Teacher("高一铭", "12345678912", "安徽淮北"),
//                new Teacher("刘二铭", "1122378912", "安徽淮北"),
//                new Teacher("Aim", "60123678912", "乌克兰"));
//        System.out.println("受影响行数： " + rows);

//        int row = base.updateOfId(4, new Teacher("王一楠", "18888888999", "河南洛阳"));
//        System.out.println("受影响行数： " + row);

//        int row = base.deleteOfId(7);
//        System.out.println("受影响行数： " + row);

    }
}
