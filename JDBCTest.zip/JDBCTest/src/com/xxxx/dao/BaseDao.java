package com.xxxx.dao;


import com.xxxx.entity.Teacher;

import java.util.List;

/**
 * 定义操作操作表中数据的行为
 */
public interface BaseDao<T> {


    /**
     * 查询操作 返回表所有数据行
     *
     * @return
     */
    List<T> queryALL() throws Exception;

    /**
     * 查询操作 按主键查询
     *
     * @return
     */
    T queryOfId(Integer id) throws Exception;


    /**
     * 插入操作 插入一条数据
     *
     * @param t 表的实体类
     * @return 受影响行数
     */
    int insert(T t) throws Exception;

    /**
     * 插入操作 插入多条数据
     *
     * @param t 表的实体类
     * @return 受影响行数
     */
    int inserts(T... t) throws Exception;


    /**
     * 更新操作 按主键更新
     *
     * @param t 表的实体类
     * @return 受影响行数
     */
    int updateOfId(Integer id, T t) throws Exception;

    /***
     * 删除操作  按主键删除
     * @return 受影响行数
     */
    int deleteOfId(Integer id) throws Exception;


}
