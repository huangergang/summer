package com.xxxx.dao.impl;

import com.xxxx.dao.BaseDao;
import com.xxxx.entity.Teacher;
import com.xxxx.util.JDBCUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class BaseDaoImpl implements BaseDao<Teacher> {

    private Connection cn;
    private PreparedStatement ps;
    private ResultSet rs;

    @Override
    public List<Teacher> queryALL() throws Exception {
        cn = JDBCUtil.getConnection();
        List<Teacher> list = new ArrayList<>();

        String sql = "SELECT * from Teacher";

        ps = cn.prepareStatement(sql);
        rs = ps.executeQuery();

        while (rs.next()) {
            list.add(new Teacher(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("phone"),
                    rs.getString("address")));
        }

        JDBCUtil.close(cn, ps, rs);

        return list;
    }

    @Override
    public Teacher queryOfId(Integer id) throws Exception {

        cn = JDBCUtil.getConnection();
        Teacher user = new Teacher();


        String sql = "SELECT id,name,phone,address from Teacher where id=?";

        ps = cn.prepareStatement(sql);
        ps.setInt(1, id);


        rs = ps.executeQuery();


        while (rs.next()) {
            user.setId(rs.getInt("id"));
            user.setName(rs.getString("name"));
            user.setPhone(rs.getString("phone"));
            user.setAddress(rs.getString("address"));
        }

        JDBCUtil.close(cn, ps, rs);

        return user;
    }

    @Override
    public int insert(Teacher user) throws Exception {
        cn = JDBCUtil.getConnection();
        String sql = "insert into teacher VALUES(null,?,?,?)";
        ps = cn.prepareStatement(sql);
        ps.setString(1, user.getName());
        ps.setString(2, user.getPhone());
        ps.setString(3, user.getAddress());

        int row = ps.executeUpdate();

        JDBCUtil.close(cn, ps);
        return row;
    }

    @Override
    public int inserts(Teacher... arr) throws Exception {
        cn = JDBCUtil.getConnection();
        String sql = "insert into teacher VALUES(null,?,?,?)";
        ps = cn.prepareStatement(sql);

        int rows = 0;
        for (int i = 0; i < arr.length; i++) {
            Teacher user = arr[i];

            ps.setString(1, user.getName());
            ps.setString(2, user.getPhone());
            ps.setString(3, user.getAddress());
            rows += ps.executeUpdate();
        }

        return rows;
    }

    @Override
    public int updateOfId(Integer id, Teacher user) throws Exception {
        cn = JDBCUtil.getConnection();
        String sql = "update teacher set name=?,phone =?,address=? where id=?";
        ps = cn.prepareStatement(sql);
        ps.setString(1, user.getName());
        ps.setString(2, user.getPhone());
        ps.setString(3, user.getAddress());
        ps.setInt(4, id);

        int row = ps.executeUpdate();

        return row;
    }

    @Override
    public int deleteOfId(Integer id) throws Exception {
        cn = JDBCUtil.getConnection();
        String sql = "delete from teacher where id = ? ";

        ps = cn.prepareStatement(sql);
        ps.setInt(1, id);

        int row = ps.executeUpdate();

        return row;
    }

}
