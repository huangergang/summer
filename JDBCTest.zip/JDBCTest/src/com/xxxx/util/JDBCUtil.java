package com.xxxx.util;


import java.io.FileInputStream;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

public class JDBCUtil {

    private static String url;
    private static String user;
    private static String password;


    /**
     *      静态代码块获取MySQL配置文件
     *
     */
    static {
        try {

            Class.forName("com.mysql.jdbc.Driver");

            FileInputStream in = new FileInputStream("db.properties");
            Properties properties = new Properties();
            properties.load(in);


            url = properties.getProperty("url");
            user = properties.getProperty("user");
            password = properties.getProperty("password");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    public static Connection getConnection() throws Exception {

        return DriverManager.getConnection(url, user, password);
    }

    public static void close(Connection cn, PreparedStatement ps) throws Exception {
        if (cn != null && ps != null) {
            cn.close();
            ps.close();
        }
    }

    public static void close(Connection cn, PreparedStatement ps, ResultSet rs) throws Exception {
        if (cn != null && ps != null && rs != null) {
            cn.close();
            ps.close();
            rs.close();
        }
    }

}
